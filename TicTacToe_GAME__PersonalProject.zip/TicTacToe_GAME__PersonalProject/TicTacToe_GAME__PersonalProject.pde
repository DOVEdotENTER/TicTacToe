// Tic Tac Toe - Simple version with nice graphics
int cell1, cell2, cell3, cell4, cell5, cell6, cell7, cell8, cell9;
int currentPlayer;
boolean gameOver;
int winner; // 0=playing, 1=X wins, 2=O wins, 3=tie

void setup() {
  size(400, 450);
  resetGame();
  textSize(32);
  textAlign(CENTER, CENTER);
}

void draw() {
  background(255);
  drawBoard();
  drawPieces();
  drawStatus();
  
  if (gameOver) {
    drawGameOver();
  }
}

void drawBoard() {
  stroke(0);
  strokeWeight(4);
  // Vertical lines
  line(150, 50, 150, 350);
  line(250, 50, 250, 350);
  // Horizontal lines
  line(50, 150, 350, 150);
  line(50, 250, 350, 250);
}

void drawPieces() {
  strokeWeight(5);
  
  // Draw X's (red) and O's (blue) for each cell
  if (cell1 == 1) { drawX(50, 50); }
  if (cell1 == 2) { drawO(50, 50); }
  
  if (cell2 == 1) { drawX(150, 50); }
  if (cell2 == 2) { drawO(150, 50); }
  
  if (cell3 == 1) { drawX(250, 50); }
  if (cell3 == 2) { drawO(250, 50); }
  
  if (cell4 == 1) { drawX(50, 150); }
  if (cell4 == 2) { drawO(50, 150); }
  
  if (cell5 == 1) { drawX(150, 150); }
  if (cell5 == 2) { drawO(150, 150); }
  
  if (cell6 == 1) { drawX(250, 150); }
  if (cell6 == 2) { drawO(250, 150); }
  
  if (cell7 == 1) { drawX(50, 250); }
  if (cell7 == 2) { drawO(50, 250); }
  
  if (cell8 == 1) { drawX(150, 250); }
  if (cell8 == 2) { drawO(150, 250); }
  
  if (cell9 == 1) { drawX(250, 250); }
  if (cell9 == 2) { drawO(250, 250); }
}

void drawX(int x, int y) {
  stroke(255, 0, 0); // Red color for X
  line(x + 20, y + 20, x + 80, y + 80);
  line(x + 80, y + 20, x + 20, y + 80);
}

void drawO(int x, int y) {
  stroke(0, 0, 255); // Blue color for O
  noFill();
  ellipse(x + 50, y + 50, 60, 60);
}

void drawStatus() {
  fill(0);
  textSize(20);
  if (!gameOver) {
    if (currentPlayer == 1) {
      text("Player X's Turn", width/2, 20);
    } else {
      text("Player O's Turn", width/2, 20);
    }
  }
}

void drawGameOver() {
  fill(0, 150);
  rect(0, 0, width, height);
  
  fill(255);
  textSize(28);
  if (winner == 1) {
    text("X Wins!", width/2, height/2 - 20);
  } else if (winner == 2) {
    text("O Wins!", width/2, height/2 - 20);
  } else if (winner == 3) {
    text("It's a Tie!", width/2, height/2 - 20);
  }
  textSize(18);
  text("Click to play again", width/2, height/2 + 20);
}

void mousePressed() {
  if (gameOver) {
    resetGame();
    return;
  }
  
  int x = mouseX;
  int y = mouseY;
  
  // Check which cell was clicked
  if (y > 50 && y < 350 && x > 50 && x < 350) {
    if (y < 150) {
      // Top row
      if (x < 150 && cell1 == 0) {
        cell1 = currentPlayer;
        checkGame();
      } else if (x < 250 && cell2 == 0) {
        cell2 = currentPlayer;
        checkGame();
      } else if (x < 350 && cell3 == 0) {
        cell3 = currentPlayer;
        checkGame();
      }
    } else if (y < 250) {
      // Middle row
      if (x < 150 && cell4 == 0) {
        cell4 = currentPlayer;
        checkGame();
      } else if (x < 250 && cell5 == 0) {
        cell5 = currentPlayer;
        checkGame();
      } else if (x < 350 && cell6 == 0) {
        cell6 = currentPlayer;
        checkGame();
      }
    } else {
      // Bottom row
      if (x < 150 && cell7 == 0) {
        cell7 = currentPlayer;
        checkGame();
      } else if (x < 250 && cell8 == 0) {
        cell8 = currentPlayer;
        checkGame();
      } else if (x < 350 && cell9 == 0) {
        cell9 = currentPlayer;
        checkGame();
      }
    }
  }
}

void checkGame() {
  // Check rows for win
  if (cell1 != 0 && cell1 == cell2 && cell2 == cell3) {
    gameOver = true;
    winner = cell1;
    return;
  }
  if (cell4 != 0 && cell4 == cell5 && cell5 == cell6) {
    gameOver = true;
    winner = cell4;
    return;
  }
  if (cell7 != 0 && cell7 == cell8 && cell8 == cell9) {
    gameOver = true;
    winner = cell7;
    return;
  }
  
  // Check columns for win
  if (cell1 != 0 && cell1 == cell4 && cell4 == cell7) {
    gameOver = true;
    winner = cell1;
    return;
  }
  if (cell2 != 0 && cell2 == cell5 && cell5 == cell8) {
    gameOver = true;
    winner = cell2;
    return;
  }
  if (cell3 != 0 && cell3 == cell6 && cell6 == cell9) {
    gameOver = true;
    winner = cell3;
    return;
  }
  
  // Check diagonals for win
  if (cell1 != 0 && cell1 == cell5 && cell5 == cell9) {
    gameOver = true;
    winner = cell1;
    return;
  }
  if (cell3 != 0 && cell3 == cell5 && cell5 == cell7) {
    gameOver = true;
    winner = cell3;
    return;
  }
  
  // Check for tie
  if (cell1 != 0 && cell2 != 0 && cell3 != 0 &&
      cell4 != 0 && cell5 != 0 && cell6 != 0 &&
      cell7 != 0 && cell8 != 0 && cell9 != 0) {
    gameOver = true;
    winner = 3; // Tie
    return;
  }
  
  // Switch player if game continues
  if (currentPlayer == 1) {
    currentPlayer = 2;
  } else {
    currentPlayer = 1;
  }
}

void resetGame() {
  cell1 = 0; cell2 = 0; cell3 = 0;
  cell4 = 0; cell5 = 0; cell6 = 0;
  cell7 = 0; cell8 = 0; cell9 = 0;
  currentPlayer = 1;
  gameOver = false;
  winner = 0;
}

void keyPressed() {
  if (key == 'r' || key == 'R') {
    resetGame();
  }
}
